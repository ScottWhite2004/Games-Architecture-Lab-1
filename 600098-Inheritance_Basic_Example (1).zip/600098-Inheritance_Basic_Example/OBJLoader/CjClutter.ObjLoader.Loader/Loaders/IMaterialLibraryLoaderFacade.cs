namespace ObjLoader.Loader.Loaders
{
    public interface IMaterialLibraryLoaderFacade
    {
        void Load(string materialFileName);
    }
}