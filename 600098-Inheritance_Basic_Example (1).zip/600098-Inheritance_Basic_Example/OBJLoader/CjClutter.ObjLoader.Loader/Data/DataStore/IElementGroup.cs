namespace ObjLoader.Loader.Data.DataStore
{
    public interface IElementGroup
    {
        void SetMaterial(string materialName);
    }
}