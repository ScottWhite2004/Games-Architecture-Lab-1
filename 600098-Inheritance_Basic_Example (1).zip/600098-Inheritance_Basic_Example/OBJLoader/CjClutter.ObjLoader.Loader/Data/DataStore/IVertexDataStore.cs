using ObjLoader.Loader.Data.VertexData;

namespace ObjLoader.Loader.Data.DataStore
{
    public interface IVertexDataStore
    {
        void AddVertex(Vertex vertex);
    }
}