namespace ObjLoader.Loader.Data.DataStore
{
    public interface IMaterialLibrary
    {
        void Push(Material material);
    }
}