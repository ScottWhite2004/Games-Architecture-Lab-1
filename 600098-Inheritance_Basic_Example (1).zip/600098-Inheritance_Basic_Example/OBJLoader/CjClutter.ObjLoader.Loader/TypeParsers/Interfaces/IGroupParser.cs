namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface IGroupParser : ITypeParser
    {
    }
}