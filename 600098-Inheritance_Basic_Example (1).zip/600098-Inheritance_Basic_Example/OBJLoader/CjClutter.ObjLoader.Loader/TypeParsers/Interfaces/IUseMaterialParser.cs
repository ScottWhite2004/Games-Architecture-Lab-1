namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface IUseMaterialParser : ITypeParser
    {
    }
}