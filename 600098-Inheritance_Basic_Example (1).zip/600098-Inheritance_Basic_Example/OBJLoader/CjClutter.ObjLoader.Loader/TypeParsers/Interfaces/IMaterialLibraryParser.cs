namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface IMaterialLibraryParser : ITypeParser
    {
    }
}